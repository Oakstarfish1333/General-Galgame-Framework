window.chapter1 = [
  {
    bg: "school_day.jpg",
    char_left: "mika_happy.png",
    name: "美香",
    text: "早上好！你今天怎么来得这么早？",
    affection: { character: "mika", change: 1 }
  },
  {
    name: "你",
    text: "想早点见到你嘛。",
    affection: { character: "mika", change: 1 }
  },
  {
    name: "美香",
    char_left: "mika_blush.png",
    text: "欸……你这人真是……"
  },
  {
    name: "美香",
    char_left: "mika_running.png",
    text: "啊不好！我忘记带作业了，我得回教室拿一下！",
    unlockCG: "cgs/mika_running.jpg"
  },
  {
    name: "你",
    text: "我陪你一起去吧？还是……你自己去？",
    choices: [
      {
        text: "陪她一起去",
        next: [
          {
            name: "美香",
            char_left: "mika_smile.png",
            text: "谢谢你，其实我还挺希望你能来的。",
            affection: { character: "mika", change: 2 }
          },
          {
            text: "你跟着美香一起回了教室，心里暖暖的。"
          }
        ]
      },
      {
        text: "让她一个人去",
        next: [
          {
            name: "美香",
            char_left: "mika_sad.png",
            text: "……也好，你就在这等我吧。",
            affection: { character: "mika", change: -1 }
          },
          {
            text: "你看着她的背影跑远，突然觉得有点失落。"
          }
        ]
      }
    ]
  },
  {
    bg: "classroom_day.jpg",
    char_left: "",
    text: "（第一章 结束）"
  }
];