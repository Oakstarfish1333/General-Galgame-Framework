const dialogueBox = document.getElementById("dialogue-box");
const nameBox = document.getElementById("name");
const textBox = document.getElementById("text");
const choicesBox = document.getElementById("choices");

let currentChapter = window.chapter1;
let dialogueIndex = 0;
let currentTyping = null;

let affection = JSON.parse(localStorage.getItem("affection")) || {};
let cgGallery = JSON.parse(localStorage.getItem("cgGallery")) || [];

// 查看当前好感度
function showAffection() {
  let msg = "当前角色好感度：\n";
  for (const [name, value] of Object.entries(affection)) {
    msg += `❤️ ${name}: ${value}\n`;
  }
  alert(msg);
}

function startGame() {
  document.getElementById("menu").style.display = "none";
  document.getElementById("game").style.display = "block";
  dialogueIndex = 0;
  showLine();
}

function showLine() {
  const line = currentChapter[dialogueIndex];
  if (!line) return;

  // 显示角色名
  nameBox.innerText = line.name || "";

  // 设置背景
  if (line.bg) {
    document.getElementById("bg").style.backgroundImage = `url(${line.bg})`;
  }

  // 设置立绘
  ["left", "center", "right"].forEach(pos => {
    const el = document.getElementById("char-" + pos);
    if (line[pos]) {
      el.style.backgroundImage = `url(${line[pos]})`;
      el.style.opacity = 1;
    } else {
      el.style.opacity = 0;
    }
  });

  // 清空选项
  choicesBox.innerHTML = "";

  // 解锁 CG
  if (line.unlockCG && !cgGallery.includes(line.unlockCG)) {
    cgGallery.push(line.unlockCG);
    localStorage.setItem("cgGallery", JSON.stringify(cgGallery));
  }

  // 好感度修改
  if (line.affection) {
    for (const [char, value] of Object.entries(line.affection)) {
      affection[char] = (affection[char] || 0) + value;
    }
    localStorage.setItem("affection", JSON.stringify(affection));
  }

  // 文本 or 选项
  if (line.text) {
    typeText(line.text);
  } else if (line.choices) {
    renderChoices(line.choices);
  }
  
    // ✅ 添加：如果有 choices，渲染选项后提前 return，避免跳过
  if (line.choices) {
    renderChoices(line.choices);
    return;
  }
}

function typeText(text) {
  let i = 0;
  currentTyping = setInterval(() => {
    if (i <= text.length) {
      textBox.innerText = text.slice(0, i++);
    } else {
      clearInterval(currentTyping);
      currentTyping = null;
    }
  }, 30);
}

dialogueBox.addEventListener("click", () => {
  if (currentTyping) {
    clearInterval(currentTyping);
    textBox.innerText = currentChapter[dialogueIndex].text;
    currentTyping = null;
  } else {
    dialogueIndex++;
    showLine();
  }
});

function renderChoices(choices) {
  choicesBox.innerHTML = ""; // 清空旧按钮
  choices.forEach(choice => {
    const btn = document.createElement("button");
    btn.innerText = choice.text;
    btn.onclick = () => {
      // 处理好感度
      if (choice.affection) {
        for (const [char, value] of Object.entries(choice.affection)) {
          affection[char] = (affection[char] || 0) + value;
        }
        localStorage.setItem("affection", JSON.stringify(affection));
      }

      // ✅ 插入 next 内容到当前章节
      if (choice.next && Array.isArray(choice.next)) {
        currentChapter.splice(dialogueIndex + 1, 0, ...choice.next);
      }

      // ✅ 跳过当前 choices 节点，执行下一个
      dialogueIndex++;
      showLine();
    };
    choicesBox.appendChild(btn);
  });
}

function saveGame() {
  const saveData = {
    index: dialogueIndex,
    affection,
    cgGallery
  };
  localStorage.setItem("save", JSON.stringify(saveData));
  alert("✅ 游戏已保存！");
}

function loadGame() {
  const save = JSON.parse(localStorage.getItem("save"));
  if (!save) return alert("❌ 没有存档数据！");
  dialogueIndex = save.index || 0;
  affection = save.affection || {};
  cgGallery = save.cgGallery || [];
  document.getElementById("menu").style.display = "none";
  document.getElementById("game").style.display = "block";
  showLine();
}

function showGallery() {
  if (cgGallery.length === 0) {
    alert("你还没有解锁任何 CG 哦！");
  } else {
    alert("🎉 已解锁 CG：\n" + cgGallery.join("\n"));
  }
}

function backToMenu() {
  document.getElementById("game").style.display = "none";
  document.getElementById("menu").style.display = "flex";
}

function showGallery() {
  document.getElementById("menu").style.display = "none";
  const cgList = document.getElementById("cg-list");
  const gallery = JSON.parse(localStorage.getItem("cgGallery")) || [];

  // 定义所有可能的 CG 名称（即使未解锁也显示）
  const allCGs = [
    "mika_running",
    "riko_smile"
    // 你可以继续添加，例如 "riko_date", "mika_snow", ...
  ];

  cgList.innerHTML = ""; // 清空旧内容
  allCGs.forEach(cgName => {
    const img = document.createElement("img");
    const isUnlocked = gallery.includes(`cgs/${cgName}.jpg`);
    img.src = isUnlocked ? `assets/thumbs/${cgName}.jpg` : `assets/thumbs/locked.jpg`;
    img.alt = cgName;
    img.onclick = () => {
      if (isUnlocked) {
        document.getElementById("preview-img").src = `assets/cgs/${cgName}.jpg`;
        document.getElementById("cg-preview").style.display = "flex";
      }
    };
    cgList.appendChild(img);
  });

  document.getElementById("cg-gallery").style.display = "block";
}

function closeGallery() {
  document.getElementById("cg-gallery").style.display = "none";
  document.getElementById("menu").style.display = "flex";
}

window.addEventListener("DOMContentLoaded", () => {
  const openingDiv = document.getElementById("opening");
  const openingVideo = document.getElementById("opening-video");
  const overlay = document.getElementById("opening-overlay");
  const poster = document.getElementById("opening-poster");

  let state = "idle"; // idle → playing → finished

  overlay.addEventListener("click", () => {
    if (state === "idle") {
      // ✅ 确保 poster 在 DOM 中 & 可见时才隐藏
      if (poster) poster.style.display = "none";

      // ✅ 播放视频（必须用户触发）
      openingVideo.currentTime = 0;
      openingVideo.muted = false;
      openingVideo.style.display = "block"; // 确保显示
      openingVideo.play().catch(err => {
        console.warn("播放失败：", err);
      });

      state = "playing";
    } else if (state === "playing") {
      // ✅ 第二次点击跳过
      openingVideo.pause();
      openingDiv.style.display = "none";
      document.getElementById("menu").style.display = "flex";
      state = "finished";
    }
  });

  // ✅ 播放完毕自动进入菜单
  openingVideo.addEventListener("ended", () => {
    if (state !== "finished") {
      openingDiv.style.display = "none";
      document.getElementById("menu").style.display = "flex";
      state = "finished";
    }
  });
});