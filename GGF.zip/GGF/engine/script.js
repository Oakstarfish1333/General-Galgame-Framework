// 当前章节的剧本将赋值到 window.currentChapter 中
// 你可以随时切换章节，只要更新 window.currentChapter 即可

window.currentChapter = window.script || [];

// 将点击对话框继续推进剧情
document.getElementById("dialogue-box").addEventListener("click", () => {
  const line = window.currentChapter[currentLine];
  if (line && line.choices) return; // 有选项时禁用点击跳过
  currentLine++;
  showLine();
});// 当前章节的剧本将赋值到 window.currentChapter 中
// 你可以随时切换章节，只要更新 window.currentChapter 即可

window.currentChapter = window.script || [];

// 将点击对话框继续推进剧情
document.getElementById("dialogue-box").addEventListener("click", () => {
  const line = window.currentChapter[currentLine];
  if (line && line.choices) return; // 有选项时禁用点击跳过
  currentLine++;
  showLine();
});

