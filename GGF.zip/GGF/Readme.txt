欢迎使用GGF框架来搭建你的Gal！
Welcome to the GGF framework to build your Gal!
建议您使用chromium内核浏览器来运行！
It is recommended that you use the Chromium kernel browser to run it!
安卓请使用simple http server来运行！因为它无法直接读取其所引用的.js之类的文件！
Android Please use Simple HTTP Server to run! Because it can't directly read files like the .js it references
剩下的自己研究吧！
Do the rest yourself!
